# Personal Layout

[Layout](http://www.keyboard-layout-editor.com/#/gists/8eae83bfb830d847c94c7ff423bbdc84)
