Keyboard: Lets split!  
Keys: 48key ortho 40% keyboard  
Layout: Swedish characters on main layer using tapdance. Built for eurkey keyboard layout.  
Flash instructions: Flash using avrdude, will req the hvp user space to compile.

> make lets_split/rev2:hvp:avrdude

Links:
Github - https://github.com/qmk/qmk_firmware/tree/master/keyboards/lets_split  
Eurkey layout - https://eurkey.steffen.bruentjen.eu/
