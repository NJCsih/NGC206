# krusli
Let's Split keymap based off the default Planck layout with a numpad layer.
