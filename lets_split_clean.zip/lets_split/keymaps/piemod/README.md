PieMod
======

A keymap for users that need:

- *P*: Programming symbols.

- *I*: i3wm.

- *E*: Emacs.

- *M*: Macros.

- *O*: Ortholinear.

- *D*: Dvorak.

Still a work-in-progress. Suggestions welcome @ https://github.com/dwrz/piemod.


### TODO

- [ ] Add Emacs layer.
- [ ] Add Macro layer.
- [ ] Add system control keys (rotation, brightness).
- [ ] Switch " and ' quotes (or function to toggle default).
- [ ] Add capslock.
.
